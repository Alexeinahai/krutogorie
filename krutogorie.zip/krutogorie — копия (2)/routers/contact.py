from fastapi import APIRouter, Request, Form
from fastapi.responses import HTMLResponse, RedirectResponse
from fastapi.templating import Jinja2Templates
from email_utils import email_contact, email_vacancy
import config

router = APIRouter()
templates = Jinja2Templates(directory="templates")


def base_ctx(request: Request, **kwargs):
    return {"request": request, "site": config, "user": request.session.get("user"), **kwargs}


@router.post("/send-contact")
async def send_contact(
    request: Request,
    name: str = Form(...),
    email: str = Form(...),
    phone: str = Form(""),
    topic: str = Form(...),
    message: str = Form(...),
):
    ok = email_contact(name, email, phone, topic, message)
    return templates.TemplateResponse("contacts.html", base_ctx(
        request,
        active="contacts",
        success=ok,
        error=None if ok else "Не удалось отправить сообщение. Попробуйте позже или свяжитесь по телефону.",
    ))


@router.post("/send-vacancy")
async def send_vacancy(
    request: Request,
    name: str = Form(...),
    email: str = Form(...),
    phone: str = Form(""),
    position: str = Form(...),
    message: str = Form(""),
):
    ok = email_vacancy(name, email, phone, position, message)
    return templates.TemplateResponse("vacancies.html", base_ctx(
        request,
        active="vacancies",
        vacancy_success=ok,
        vacancy_error=None if ok else "Не удалось отправить отклик. Попробуйте позже.",
        # Передаём вакансии обратно
        jobs=[],  # В реальном проекте вынести данные в отдельный модуль
    ))
