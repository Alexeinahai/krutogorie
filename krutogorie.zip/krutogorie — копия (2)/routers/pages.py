from fastapi import APIRouter, Request, Depends
from fastapi.responses import HTMLResponse
from fastapi.templating import Jinja2Templates
from auth_utils import get_current_user_optional
import config

router = APIRouter()
templates = Jinja2Templates(directory="templates")


def base_ctx(request: Request, **kwargs):
    """Базовый контекст для всех страниц."""
    return {
        "request": request,
        "site": config,
        "user": request.session.get("user"),
        **kwargs
    }


@router.get("/", response_class=HTMLResponse)
async def index(request: Request):
    return templates.TemplateResponse("index.html", base_ctx(request, active="home"))


@router.get("/about", response_class=HTMLResponse)
async def about(request: Request):
    return templates.TemplateResponse("about.html", base_ctx(request, active="about"))


@router.get("/products", response_class=HTMLResponse)
async def products(request: Request):
    # Каталог продукции
    catalog = [
        {
            "id": 1, "category": "Молочная продукция",
            "items": [
                {"name": "Молоко цельное", "unit": "л", "desc": "Свежее цельное молоко собственного производства"},
                {"name": "Сливки", "unit": "л", "desc": "Натуральные сливки 20% жирности"},
                {"name": "Сметана", "unit": "кг", "desc": "Домашняя сметана 25% жирности"},
            ]
        },
        {
            "id": 2, "category": "Мясная продукция",
            "items": [
                {"name": "Говядина", "unit": "кг", "desc": "Охлаждённая говядина, различные категории"},
                {"name": "Свинина", "unit": "кг", "desc": "Свинина от собственного свиноводческого комплекса"},
            ]
        },
        {
            "id": 3, "category": "Растениеводство",
            "items": [
                {"name": "Картофель", "unit": "кг", "desc": "Свежий картофель, хранение до 8 000 тонн"},
                {"name": "Зерно (пшеница)", "unit": "т", "desc": "Продовольственная и фуражная пшеница"},
                {"name": "Рапс", "unit": "т", "desc": "Рапс собственного производства и переработки"},
                {"name": "Овощи", "unit": "кг", "desc": "Свежие овощи сезонного производства"},
            ]
        },
    ]
    return templates.TemplateResponse("products.html", base_ctx(request, active="products", catalog=catalog))


@router.get("/vacancies", response_class=HTMLResponse)
async def vacancies(request: Request):
    jobs = [
        {
            "title": "Оператор роботизированной фермы",
            "type": "Полная занятость",
            "salary": "от 1 200 BYN",
            "desc": "Обслуживание роботизированного доильного оборудования, контроль состояния животных, ведение отчётности.",
            "requirements": ["Среднее специальное / высшее образование", "Опыт работы с животными приветствуется", "Ответственность, внимательность"],
        },
        {
            "title": "Тракторист-машинист",
            "type": "Полная занятость",
            "salary": "от 1 100 BYN",
            "desc": "Проведение полевых работ на современной технике: посев, уборка урожая, обработка почвы.",
            "requirements": ["Удостоверение тракториста-машиниста", "Опыт работы от 1 года", "Знание современной с/х техники"],
        },
        {
            "title": "Зоотехник",
            "type": "Полная занятость",
            "salary": "от 1 400 BYN",
            "desc": "Контроль кормления и содержания скота, разработка рационов, ведение зоотехнического учёта.",
            "requirements": ["Высшее зоотехническое образование", "Опыт работы от 2 лет", "Знание программ учёта животных"],
        },
        {
            "title": "Агроном",
            "type": "Полная занятость",
            "salary": "от 1 500 BYN",
            "desc": "Планирование и контроль агрономических работ, разработка технологий возделывания культур.",
            "requirements": ["Высшее агрономическое образование", "Опыт работы от 3 лет", "Знание современных технологий"],
        },
        {
            "title": "Бухгалтер",
            "type": "Полная занятость",
            "salary": "от 1 200 BYN",
            "desc": "Ведение бухгалтерского и налогового учёта предприятия.",
            "requirements": ["Высшее экономическое образование", "Опыт работы от 2 лет", "Знание 1С:Предприятие"],
        },
        {
            "title": "Водитель категории C/E",
            "type": "Полная занятость",
            "salary": "от 1 000 BYN",
            "desc": "Перевозка сельскохозяйственной продукции и грузов по маршрутам предприятия.",
            "requirements": ["Водительское удостоверение C, E", "Опыт вождения грузовых автомобилей", "Аккуратность, пунктуальность"],
        },
    ]
    return templates.TemplateResponse("vacancies.html", base_ctx(request, active="vacancies", jobs=jobs))


@router.get("/news", response_class=HTMLResponse)
async def news(request: Request):
    articles = [
        {
            "id": 1,
            "date": "15 мая 2025",
            "tag": "Растениеводство",
            "title": "Начало посевной кампании 2025 года",
            "preview": "В этом году хозяйство засевает расширенные площади пшеницей и ячменём. Современная техника позволяет провести работы в сжатые сроки.",
            "icon": "🌱",
        },
        {
            "id": 2,
            "date": "3 апреля 2025",
            "tag": "Животноводство",
            "title": "Роботизированная ферма вышла на проектную мощность",
            "preview": "Автоматическая система доения увеличила производительность на 18% и значительно улучшила качество молока.",
            "icon": "🤖",
        },
        {
            "id": 3,
            "date": "18 марта 2025",
            "tag": "Достижения",
            "title": "Лучшие показатели молочного производства по области",
            "preview": "По итогам I квартала хозяйство заняло лидирующие позиции среди предприятий Минской области по надою молока на корову.",
            "icon": "🏆",
        },
        {
            "id": 4,
            "date": "5 февраля 2025",
            "tag": "Социальная сфера",
            "title": "Новые рабочие места и повышение зарплат",
            "preview": "Предприятие открыло 35 новых вакансий и провело плановое повышение заработной платы для сотрудников.",
            "icon": "👥",
        },
    ]
    return templates.TemplateResponse("news.html", base_ctx(request, active="news", articles=articles))


@router.get("/contacts", response_class=HTMLResponse)
async def contacts(request: Request):
    return templates.TemplateResponse("contacts.html", base_ctx(request, active="contacts"))


@router.get("/admin", response_class=HTMLResponse)
async def admin_page(request: Request):
    if not request.session.get("user"):
        from fastapi.responses import RedirectResponse
        return RedirectResponse("/login", status_code=302)
    return templates.TemplateResponse("admin.html", base_ctx(request, active="admin"))
