(function() {

const skyCanvas   = document.getElementById('heroSky');
const wheatCanvas = document.getElementById('heroWheat');
if (!skyCanvas || !wheatCanvas) return;

const sCtx = skyCanvas.getContext('2d');
const wCtx = wheatCanvas.getContext('2d');

let W = 0, H = 0;
let progress = 0;
let targetProgress = 0;

function resize() {
  W = skyCanvas.offsetWidth;
  H = skyCanvas.offsetHeight;
  skyCanvas.width   = wheatCanvas.width  = W;
  skyCanvas.height  = wheatCanvas.height = H;
  initStalks();
}

const skyStops = [
  { t: 0.0,  hor: '#FF6B35', zen: '#1a1035', grd: '#2a1505' },
  { t: 0.2,  hor: '#FFB347', zen: '#4a7fc1', grd: '#3d5c1a' },
  { t: 0.45, hor: '#87CEEB', zen: '#1a6baa', grd: '#4a7a20' },
  { t: 0.7,  hor: '#FFA07A', zen: '#2c3e7a', grd: '#3d5c1a' },
  { t: 0.85, hor: '#FF4500', zen: '#0d1b3e', grd: '#1a2e05' },
  { t: 1.0,  hor: '#2c1654', zen: '#050a18', grd: '#0d1a03' },
];

function lerp(a, b, t) { return a + (b - a) * t; }
function hexToRgb(h) { return [parseInt(h.slice(1,3),16),parseInt(h.slice(3,5),16),parseInt(h.slice(5,7),16)]; }
function lerpColor(c1, c2, t) {
  const a=hexToRgb(c1),b=hexToRgb(c2);
  return `rgb(${Math.round(lerp(a[0],b[0],t))},${Math.round(lerp(a[1],b[1],t))},${Math.round(lerp(a[2],b[2],t))})`;
}
function getSky(p) {
  let lo=skyStops[0],hi=skyStops[skyStops.length-1];
  for(let i=0;i<skyStops.length-1;i++){if(p>=skyStops[i].t&&p<=skyStops[i+1].t){lo=skyStops[i];hi=skyStops[i+1];break;}}
  const t=(p-lo.t)/(hi.t-lo.t+1e-4);
  return {horizon:lerpColor(lo.hor,hi.hor,t),zenith:lerpColor(lo.zen,hi.zen,t),ground:lerpColor(lo.grd,hi.grd,t)};
}

const stars = Array.from({length:120},()=>({x:Math.random(),y:Math.random()*.72,r:Math.random()*1.2+.3,tw:Math.random()*Math.PI*2}));
function drawStars(p,time){
  const alpha=p<.1?p/.1*.4:p>.7?(p-.7)/.3*.9:0;
  if(alpha<.01)return;
  stars.forEach(s=>{
    sCtx.globalAlpha=alpha*(.7+.3*Math.sin(s.tw+time*.001));
    sCtx.fillStyle='#fff';sCtx.beginPath();sCtx.arc(s.x*W,s.y*H,s.r,0,Math.PI*2);sCtx.fill();
  });
  sCtx.globalAlpha=1;
}

function drawCelestial(p){
  const sunX=W*(1-p/.85),sunY=H*.75-Math.sin(Math.PI*p/.85)*H*.68;
  if(p<.88){
    const ga=(p<.15||p>.75)?.5:.25;
    const gl=sCtx.createRadialGradient(sunX,sunY,5,sunX,sunY,80);
    gl.addColorStop(0,`rgba(255,220,100,${ga})`);gl.addColorStop(1,'rgba(255,180,50,0)');
    sCtx.fillStyle=gl;sCtx.beginPath();sCtx.arc(sunX,sunY,80,0,Math.PI*2);sCtx.fill();
    sCtx.fillStyle=(p<.2||p>.72)?'#FF8C42':'#FFE066';
    sCtx.beginPath();sCtx.arc(sunX,sunY,(p<.15||p>.75)?26:20,0,Math.PI*2);sCtx.fill();
  }
  if(p>.82){
    const ma=Math.min(1,(p-.82)/.1);const mx=W*.8,my=H*.18;
    sCtx.globalAlpha=ma;sCtx.fillStyle='#e8e0c8';
    sCtx.beginPath();sCtx.arc(mx,my,18,0,Math.PI*2);sCtx.fill();
    sCtx.fillStyle=getSky(p).zenith;
    sCtx.beginPath();sCtx.arc(mx+8,my,16,0,Math.PI*2);sCtx.fill();
    sCtx.globalAlpha=1;
  }
}

class WheatStalk {
  constructor(x,baseY,maxH,phase){
    this.x=x;this.baseY=baseY;this.maxH=maxH;this.phase=phase;
    this.swayAmp=3+Math.random()*4;this.swayFreq=.5+Math.random()*.5;
    this.la=[(Math.random()-.5)*.6,(Math.random()-.5)*.6];
  }
  draw(ctx,growP,time){
    const grow=Math.min(1,growP*1.3);if(grow<=0)return;
    const height=this.maxH*grow,topY=this.baseY-height;
    const sway=Math.sin(time*.0008*this.swayFreq+this.phase)*this.swayAmp*grow;
    const heavy=grow>.7?(grow-.7)/.3:0;
    const r=Math.round(lerp(60,200,grow)),g=Math.round(lerp(90,160,grow)*lerp(1,.85,heavy)),b=Math.round(lerp(20,40,grow));
    const col=`rgb(${r},${g},${b})`;
    const cx=this.x+sway*.5,cy=this.baseY-height*.55,tx=this.x+sway+heavy*8,ty=topY;
    ctx.strokeStyle=col;ctx.lineWidth=1.5+grow;ctx.lineCap='round';
    ctx.beginPath();ctx.moveTo(this.x,this.baseY);ctx.quadraticCurveTo(cx,cy,tx,ty);ctx.stroke();
    if(grow>.25){
      const lg=Math.min(1,(grow-.25)/.35);
      for(let li=0;li<2;li++){
        const lf=li===0?.35:.6,lx=lerp(this.x,cx,lf*.7),ly=lerp(this.baseY,cy,lf*.7);
        const ll=18*lg*grow,ang=this.la[li]+sway*.04,dir=li===0?1:-1;
        ctx.strokeStyle=col;ctx.lineWidth=1;ctx.beginPath();ctx.moveTo(lx,ly);
        ctx.lineTo(lx+Math.cos(ang)*ll*dir,ly-Math.sin(Math.abs(ang))*ll*.5);ctx.stroke();
      }
    }
    if(grow>.6)this._ear(ctx,tx,ty,heavy,Math.min(1,(grow-.6)/.4),col,time);
  }
  _ear(ctx,x,y,heavy,eg,col,time){
    const el=20*eg,droop=heavy*18+Math.sin(time*.001+this.phase)*1.5;
    const ex=x+droop*.3,ey=y;
    ctx.strokeStyle=col;ctx.lineWidth=1.5;
    ctx.beginPath();ctx.moveTo(ex,ey);ctx.lineTo(ex+droop*.4,ey+el);ctx.stroke();
    for(let i=0;i<8;i++){
      const t=i/7,gx=lerp(ex,ex+droop*.4,t),gy=ey+el*t;
      const al=(5+Math.sin(t*Math.PI)*6)*eg,aa=.4+t*.2+droop*.015;
      ctx.lineWidth=.8;
      [1,-1].forEach(d=>{ctx.beginPath();ctx.moveTo(gx,gy);ctx.lineTo(gx+Math.cos(aa)*al*d,gy-Math.sin(aa)*al*.3);ctx.stroke();});
      ctx.fillStyle=`rgba(${Math.round(lerp(120,220,t))},${Math.round(lerp(140,170,t))},40,0.9)`;
      ctx.beginPath();ctx.ellipse(gx,gy,2.5,3.5,0,0,Math.PI*2);ctx.fill();
    }
  }
}

let stalks=[];
function initStalks(){
  stalks=[];
  for(let layer=0;layer<7;layer++){
    const lt=layer/6,gY=H*(.72+lt*.18),count=Math.round(14+lt*22);
    const maxH=lerp(H*.22,H*.36,lt),sp=W/count;
    for(let i=0;i<count;i++){
      stalks.push(new WheatStalk(sp*i+sp*(.2+Math.random()*.6),gY,maxH*(.75+Math.random()*.5),Math.random()*Math.PI*2));
    }
  }
}

const timeLabels=[{t:0,l:'Рассвет'},{t:.2,l:'Утро'},{t:.45,l:'Полдень'},{t:.7,l:'Вечер'},{t:.85,l:'Закат'},{t:.95,l:'Ночь'}];
function getTimeLabel(p){let l=timeLabels[0].l;timeLabels.forEach(x=>{if(p>=x.t)l=x.l;});return l;}

function draw(time){
  progress+=(targetProgress-progress)*.07;
  const p=progress,c=getSky(p);

  sCtx.clearRect(0,0,W,H);
  const g=sCtx.createLinearGradient(0,0,0,H*.78);
  g.addColorStop(0,c.zenith);g.addColorStop(.6,c.horizon);g.addColorStop(1,c.ground);
  sCtx.fillStyle=g;sCtx.fillRect(0,0,W,H);
  drawStars(p,time);drawCelestial(p);

  const m=c.ground.match(/\d+/g).map(Number);
  const hz=sCtx.createLinearGradient(0,H*.5,0,H*.8);
  hz.addColorStop(0,'rgba(0,0,0,0)');hz.addColorStop(1,`rgba(${m[0]},${m[1]},${m[2]},.4)`);
  sCtx.fillStyle=hz;sCtx.fillRect(0,H*.5,W,H*.3);
  const gr2=sCtx.createLinearGradient(0,H*.72,0,H);
  gr2.addColorStop(0,c.ground);gr2.addColorStop(1,`rgb(${Math.max(0,m[0]-20)},${Math.max(0,m[1]-20)},${Math.max(0,m[2]-20)})`);
  sCtx.fillStyle=gr2;sCtx.fillRect(0,H*.72,W,H*.28);

  wCtx.clearRect(0,0,W,H);
  const growP=Math.min(1,p*1.8);
  stalks.forEach(s=>s.draw(wCtx,growP,time));

  const tl=document.getElementById('heroTimeLabel');
  const pr=document.getElementById('heroProgress');
  const hd=document.getElementById('heroHud');
  if(tl)tl.textContent=getTimeLabel(p);
  if(pr)pr.style.width=(p*100)+'%';
  if(hd)hd.style.opacity=p<.05?'1':'0';

  requestAnimationFrame(draw);
}

function onWheel(e){
  if(targetProgress>=1&&e.deltaY>0)return;
  if(targetProgress<=0&&e.deltaY<0)return;
  e.preventDefault();
  targetProgress=Math.max(0,Math.min(1,targetProgress+e.deltaY*.0012));
}
window.addEventListener('wheel',onWheel,{passive:false});

let ty0=null;
window.addEventListener('touchstart',e=>{ty0=e.touches[0].clientY;});
window.addEventListener('touchmove',e=>{
  if(ty0===null)return;
  const dy=ty0-e.touches[0].clientY;ty0=e.touches[0].clientY;
  if(targetProgress<=0&&dy<0)return;
  if(targetProgress>=1&&dy>0)return;
  e.preventDefault();
  targetProgress=Math.max(0,Math.min(1,targetProgress+dy*.004));
},{passive:false});

window.addEventListener('resize',resize);
resize();
requestAnimationFrame(draw);
})();
